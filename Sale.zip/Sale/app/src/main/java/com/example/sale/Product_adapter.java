package com.example.sale;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class Product_adapter extends RecyclerView.Adapter<Product_adapter.ViewHolder>{

    Context context;


    ArrayList<product_modelclass> list;

    public Product_adapter(Context context, ArrayList<product_modelclass> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.product_item,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {


        product_modelclass productModelclass = list.get(position);
        holder.Particular.setText(productModelclass.getParticular());
        holder.Description.setText(productModelclass.getDescription());
        holder.Unit.setText(productModelclass.getUnit());
        holder.Price.setText(productModelclass.getPrice());
        holder.Gst_number.setText(productModelclass.getgST());

    }

    @Override
    public int getItemCount() {
        return list.size();

    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        private TextView Sl_number,Particular,Description,Unit,Price,Stock,Gst_number;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);



            Particular = itemView.findViewById(R.id.particular);
            Description = itemView.findViewById(R.id.description);
            Stock = itemView.findViewById(R.id.stock);
            Unit = itemView.findViewById(R.id.unit);
            Price = itemView.findViewById(R.id.price);
            Gst_number = itemView.findViewById(R.id.gst);


        }


    }
}
