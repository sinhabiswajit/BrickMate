package com.example.sale;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.UUID;

public class TempActivity extends AppCompatActivity implements View.OnClickListener {

    LinearLayout linearLayout;
    TextView buttonAdd,buttonRemove;
    EditText P_Name, P_Uom, P_Price, GST_Rate, P_Quantity, P_TotalPrice;
    EditText Search_Customer ,Customer_name, Customer_number,Customer_GST,Customer_Address,Delivery_Address;

    RelativeLayout SaveBtn;

    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference,myRef,productRef;

    ValueEventListener listener;
    ArrayAdapter<String> adapter;
    ArrayList<String> spinnerDataList;
    private String ValueDatabase;
    private String refinedData;
    TextView Search;
    TextView SearchBtn;
    ProgressDialog Dialog;
    Spinner spinner;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_temp);

        linearLayout = findViewById(R.id.layout_list);
        buttonAdd = findViewById(R.id.add_btn);
        Delivery_Address = findViewById(R.id.d_address);
        Customer_name = findViewById(R.id.etFirstName);
        Customer_number = findViewById(R.id.p_number);
        Customer_GST = findViewById(R.id.GST);
        Customer_Address = findViewById(R.id.add);
        Search_Customer = findViewById(R.id.searchEditText);
        SearchBtn = findViewById(R.id.search);

        SaveBtn = findViewById(R.id.save_btn);


        buttonAdd.setOnClickListener(this);
        SaveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveData();
            }
        });


        View cricketerView = getLayoutInflater().inflate(R.layout.addproduct,null,false);
        P_Name = (EditText)cricketerView.findViewById(R.id.productName);
        P_Uom = (EditText)cricketerView.findViewById(R.id.uom);
        P_Price= (EditText)cricketerView.findViewById(R.id.price);
        GST_Rate = (EditText)cricketerView.findViewById(R.id.gst_rate);
        P_Quantity = (EditText)cricketerView.findViewById(R.id.qnt);
        P_TotalPrice = (EditText)cricketerView.findViewById(R.id.total);
        spinner = (Spinner)cricketerView.findViewById(R.id.productspinner);
        buttonRemove = (TextView)cricketerView.findViewById(R.id.remove_btn);
        buttonRemove.setVisibility(View.GONE);
        linearLayout.addView(cricketerView);

        myRef = FirebaseDatabase.getInstance().getReference("Customer");

        databaseReference = FirebaseDatabase.getInstance().getReference();
        spinnerDataList = new ArrayList<>();



        spinner.setAdapter(adapter);
        spinnerData();

        SearchBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String search = Search_Customer.getText().toString();
                DatabaseReference readRef = FirebaseDatabase.getInstance().getReference();
                DatabaseReference dref = readRef.child("Customer");
                Query query = dref.orderByChild("phone_number").equalTo(search);

                query.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if(dataSnapshot.exists()){
                            for(DataSnapshot ds : dataSnapshot.getChildren()){
                                Customer_name.setText((ds.child("customer_name").getValue().toString()));
                                Customer_number.setText((ds.child("phone_number").getValue().toString()));
                                Customer_Address.setText((ds.child("address").getValue().toString()));
                                Customer_GST.setText((ds.child("gst").getValue().toString()));
                            }
                        }
                        else
                            Toast.makeText(getApplicationContext(),"No Source to Display",Toast.LENGTH_SHORT).show();

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            }
        });
        P_Quantity.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (charSequence.length() != 0) {
                    if (!P_Price.getText().toString().equalsIgnoreCase("")) {
                        float a = Float.parseFloat(P_Price.getText().toString());
                        float b = Float.parseFloat(P_Quantity.getText().toString());
                        float c = a * b;
                        P_TotalPrice.setText(String.valueOf(c));
                    }
                }
                if (charSequence.length() == 0) {
                    P_TotalPrice.setText("");
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

                String state = spinner.getSelectedItem().toString();
                DatabaseReference sref = databaseReference.child("Product");
                Query query1 = sref.orderByChild("particular").equalTo(state);

                query1.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if(snapshot.exists()){
                            for(DataSnapshot ds : snapshot.getChildren()){
                                P_Name.setText((ds.child("particular").getValue().toString()));
                                GST_Rate.setText((ds.child("gST").getValue().toString()));
                                P_Uom.setText((ds.child("unit").getValue().toString()));
                                P_Price.setText((ds.child("price").getValue().toString()));
                            }
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


    }

    private void saveData() {

        String C_name = Customer_name.getText().toString();
        String C_number = Customer_number.getText().toString();
        String gst_number = Customer_GST.getText().toString();
        String C_address = Customer_Address.getText().toString();
        String p_name = P_Name.getText().toString();
        String p_uom = P_Uom.getText().toString();
        String p_price = P_Price.getText().toString();
        String Gst_rate = GST_Rate.getText().toString();
        String p_quantity = P_Quantity.getText().toString();
        String P_total = P_TotalPrice.getText().toString();
        String Delivery_address = Delivery_Address.getText().toString();

        if (TextUtils.isEmpty(C_name) && TextUtils.isEmpty(C_number) && TextUtils.isEmpty(gst_number)
                && TextUtils.isEmpty(C_address) && TextUtils.isEmpty(p_name) &&
                TextUtils.isEmpty(p_uom) && TextUtils.isEmpty(p_price) && TextUtils.isEmpty(Gst_rate)
                && TextUtils.isEmpty(p_quantity) && TextUtils.isEmpty(P_total) && TextUtils.isEmpty(Delivery_address)) {
            Toast.makeText(TempActivity.this, "Please fill up the mandatory fields", Toast.LENGTH_LONG).show();
            return;
        }
        else {
            String id = String.valueOf(UUID.randomUUID());

            OrderModel orderModel = new OrderModel(id,C_name,C_number,gst_number,C_address,p_name,p_uom,p_price,
                    Gst_rate,p_quantity,P_total,Delivery_address);

//            productRef = firebaseDatabase.getReference("OrderProduct");
            productRef = FirebaseDatabase.getInstance().getReference("OrderProduct")
                    .child(id);

            productRef.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if (snapshot.exists()){
                        snapshot.getChildrenCount();
                        startActivity(new Intent(TempActivity.this, DashboardActivity.class));
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });

            productRef.child(C_number).push().setValue(orderModel);
//            productRef.child(id).setValue(orderModel).addOnCompleteListener(new OnCompleteListener<Void>() {
//                @Override
//                public void onComplete(@NonNull Task<Void> task) {
//                    if (task.isSuccessful()){
//                        startActivity(new Intent(TempActivity.this, DashboardActivity.class));
//                    }
//                }
//            }).addOnFailureListener(new OnFailureListener() {
//                @Override
//                public void onFailure(@NonNull Exception e) {
//                    e.printStackTrace();
//                }
//            });



        }
    }

    private void spinnerData() {
        databaseReference.child("Product").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                spinnerDataList.clear();
                for (DataSnapshot item:snapshot.getChildren()){
                    spinnerDataList.add(item.child("particular").getValue(String.class));

                }
                adapter = new ArrayAdapter<String>(TempActivity.this,
                        android.R.layout.simple_dropdown_item_1line,spinnerDataList);
                spinner.setAdapter(adapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
    @Override
    public void onClick(View view) {
        addView();


    }
    private void addView() {
        View cricketerView = getLayoutInflater().inflate(R.layout.addproduct,null,false);
        P_Name = (EditText)cricketerView.findViewById(R.id.productName);
        P_Uom = (EditText)cricketerView.findViewById(R.id.uom);
        P_Price= (EditText)cricketerView.findViewById(R.id.price);
        GST_Rate = (EditText)cricketerView.findViewById(R.id.gst_rate);
        P_Quantity = (EditText)cricketerView.findViewById(R.id.qnt);
        P_TotalPrice = (EditText)cricketerView.findViewById(R.id.total);
        buttonRemove = (TextView)cricketerView.findViewById(R.id.remove_btn);
        spinner = (Spinner)cricketerView.findViewById(R.id.productspinner);
        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

                String state = spinner.getSelectedItem().toString();
                DatabaseReference sref = databaseReference.child("Product");
                Query query1 = sref.orderByChild("particular").equalTo(state);

                query1.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if(snapshot.exists()){
                            for(DataSnapshot ds : snapshot.getChildren()){
                                P_Name.setText((ds.child("particular").getValue().toString()));
                                GST_Rate.setText((ds.child("gST").getValue().toString()));
                                P_Uom.setText((ds.child("unit").getValue().toString()));
                                P_Price.setText((ds.child("price").getValue().toString()));
                            }
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        P_Quantity.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (charSequence.length() != 0) {
                    if (!P_Price.getText().toString().equalsIgnoreCase("")) {
                        float a = Float.parseFloat(P_Price.getText().toString());
                        float b = Float.parseFloat(P_Quantity.getText().toString());
                        float c = a * b;
                        P_TotalPrice.setText(String.valueOf(c));
                    }
                }
                if (charSequence.length() == 0) {
                    P_TotalPrice.setText("");
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
//

        buttonRemove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                removeView(cricketerView);

            }
        });
        linearLayout.addView(cricketerView);



    }
    private void removeView(View cricketerView) {

        linearLayout.removeView(cricketerView);
    }


}