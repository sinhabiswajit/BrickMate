package com.example.sale;

public class customer_model {

 private String id;
    private String customer_name;
    private String phone_number;
    private String email;
    private String delivery_address;
    private String address;
    private String gst;

    public customer_model() {
    }

    public customer_model(String id, String customer_name, String phone_number, String email, String delivery_address, String address, String gst) {
        this.id = id;
        this.customer_name = customer_name;
        this.phone_number = phone_number;
        this.email = email;
        this.delivery_address = delivery_address;
        this.address = address;
        this.gst = gst;

    }
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCustomer_name() {
        return customer_name;
    }

    public void setCustomer_name(String customer_name) {
        this.customer_name = customer_name;
    }

    public String getPhone_number() {
        return phone_number;
    }

    public void setPhone_number(String phone_number) {
        this.phone_number = phone_number;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDelivery_address() {
        return delivery_address;
    }

    public void setDelivery_address(String delivery_address) {
        this.delivery_address = delivery_address;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getGst() {
        return gst;
    }

    public void setGst(String gst) {
        this.gst = gst;
    }
}

