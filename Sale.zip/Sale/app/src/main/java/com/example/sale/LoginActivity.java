package com.example.sale;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class LoginActivity extends AppCompatActivity {


    EditText etEmail;
    EditText etPassword;
    RelativeLayout login;
    ProgressDialog dialog;
    CheckBox checkBox;
    TextView forgotPass;
    TextView Sign_Up;

    FirebaseAuth mAuth;

//    @Override
//    public void onBackPressed() {
//        return;
//    }


    public  static final String fileName = "Login";
    public  static final String UserName = "Username";
    public  static final String Password = "password";


    @Override
    protected void onStart() {
        super.onStart();
        if (mAuth.getCurrentUser() !=null){
            Intent i = new Intent(LoginActivity.this,DashboardActivity.class);
            startActivity(i);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);



        etEmail = findViewById(R.id.etNumber);
        etPassword = findViewById(R.id.etpassword);
        login = findViewById(R.id.login_btn);
        forgotPass = findViewById(R.id.forgotPass);
        Sign_Up = findViewById(R.id.sign_up);

        mAuth =  FirebaseAuth.getInstance();
//        if(mAuth != null){
//            Intent i = new Intent(LoginActivity.this,DashboardActivity.class);
//            startActivity(i);
//        }


        login.setOnClickListener(view -> {
            loginUser();
        });

        SharedPreferences sharedPreferences= getSharedPreferences(fileName, Context.MODE_PRIVATE);

        if (sharedPreferences.contains(UserName))
        {
            Intent i = new Intent(LoginActivity.this,DashboardActivity.class);
            startActivity(i);
        }


        Sign_Up = findViewById(R.id.sign_up);
        Sign_Up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(LoginActivity.this,RegisterActivity.class);
                startActivity(i);
            }
        });


        checkBox = findViewById(R.id.check);
        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    etPassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                } else {
                    etPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                }
            }
        });

        forgotPass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder1 = new AlertDialog.Builder(LoginActivity.this);
                builder1.setMessage("Please Contact your Developer")
                        .setCancelable(false)
                        .setPositiveButton("Okay", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {

                            }
                        });

                AlertDialog alert11 = builder1.create();
                alert11.show();
            }
        });
    }




    private void loginUser() {

        String email = etEmail.getText().toString();
        String password = etPassword.getText().toString();

        if (TextUtils.isEmpty(email)){
            etEmail.setError("Email cannot be empty");
            etEmail.requestFocus();
        }if (TextUtils.isEmpty(password)){
            etPassword.setError("Password cannot be empty");
            etPassword.requestFocus();
        } else{
            mAuth.signInWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful())
                    {
                        SharedPreferences pref = getSharedPreferences("fileName", Context.MODE_PRIVATE);
                        SharedPreferences.Editor editor = pref.edit();
                        editor.putString(UserName,email);
                        editor.putString(Password,password);
                        editor.apply();
                        Toast.makeText(LoginActivity.this, "User Login Successfully", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(LoginActivity.this, DashboardActivity.class));
                    }else{
                        Toast.makeText(LoginActivity.this, "Login Error", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }
    }
}