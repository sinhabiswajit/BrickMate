package com.example.sale;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class Customer_adapter extends RecyclerView.Adapter<Customer_adapter.ViewHolder> {

    Context context;
    ProgressBar progressBar;


    ArrayList<customer_model> list;

    public Customer_adapter(Context context, ArrayList<customer_model> list) {
        this.context = context;
        this.list = list;
    }



    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.customer_item,parent,false);
        return new ViewHolder(view);

    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {


        customer_model customerModel = list.get(position);
        holder.Customer_name.setText(customerModel.getCustomer_name());
        holder.Phone_number.setText(customerModel.getPhone_number());
        holder.Email.setText(customerModel.getEmail());
        holder.Address.setText(customerModel.getAddress());
        holder.Delivery_Address.setText(customerModel.getDelivery_address());
        holder.Gst_number.setText(customerModel.getGst());


    }

    @Override
    public int getItemCount() {

        return list.size();

    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        private TextView Customer_name,Phone_number,Email,Address,Delivery_Address,Gst_number;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);


//            Sl_number = itemView.findViewById(R.id.sl_no);
            Customer_name = itemView.findViewById(R.id.c_no);
            Phone_number = itemView.findViewById(R.id.m_no);
            Email = itemView.findViewById(R.id.e_add);
            Address = itemView.findViewById(R.id.add);
            Delivery_Address = itemView.findViewById(R.id.d_add);
            Gst_number = itemView.findViewById(R.id.gst);
            progressBar = itemView.findViewById(R.id.Progressbar);

        }

    }




}
