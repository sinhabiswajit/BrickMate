package com.example.sale;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.UUID;

public class New_CustomerActivity extends AppCompatActivity {

    ImageView back;
    EditText etC_name, etE_ID, etphone_no, etDelivery_add, etCustomer_Add, etGST_no;
    RelativeLayout Save;


    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    ProgressDialog Dialog;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_customer);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        etC_name = findViewById(R.id.etFirstName);
        etE_ID = findViewById(R.id.email_id);
        etphone_no = findViewById(R.id.p_number);
        etDelivery_add = findViewById(R.id.d_address);
        etCustomer_Add = findViewById(R.id.add);
        etGST_no = findViewById(R.id.GST);
        Save = findViewById(R.id.save);


        firebaseDatabase = FirebaseDatabase.getInstance();


        Save.setOnClickListener(view ->
                SaveData()

        );
//        back = findViewById(R.id.back);
//
//        back.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                onBackPressed();
//                startActivity(new Intent(New_CustomerActivity.this, Customer_masterdata.class));
//
//            }
//        });
    }

    private void SaveData() {


        String name = etC_name.getText().toString();
        String phone_number = etphone_no.getText().toString();
        String Email = etE_ID.getText().toString();
        String Delivery_add = etDelivery_add.getText().toString();
        String Customer_add = etCustomer_Add.getText().toString();
        String GST = etGST_no.getText().toString();

        if (TextUtils.isEmpty(name) && TextUtils.isEmpty(Email) && TextUtils.isEmpty(phone_number)
                && TextUtils.isEmpty(Delivery_add) && TextUtils.isEmpty(Customer_add) && TextUtils.isEmpty(GST)) {

            Toast.makeText(New_CustomerActivity.this, "Please add some data.", Toast.LENGTH_SHORT).show();
        } else {


            String id = String.valueOf(UUID.randomUUID());


            customer_model customerModelNew = new customer_model(id, name, phone_number, Email,
                    Delivery_add, Customer_add, GST);
//            new customer_model("","","","","","","");

            databaseReference = firebaseDatabase.getReference("Customer");
            databaseReference.child(id).setValue(customerModelNew).addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    if (task.isSuccessful()) {
                        Toast.makeText(New_CustomerActivity.this, "Added Successfully", Toast.LENGTH_SHORT).show();
                        finish();
//                        startActivity(new Intent(New_CustomerActivity.this, Customer_masterdata.class));
                    }
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    e.printStackTrace();
                }
            });


//            addDatatoFirebase(name, Email, phone_number,Delivery_add,Customer_add,GST);
        }

    }


}