package com.example.sale;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class Product_Master extends AppCompatActivity {

    RecyclerView recyclerView;
    Product_adapter adapter;
    LinearLayoutManager linearLayoutManager;
    FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
    DatabaseReference databaseReference = firebaseDatabase.getReference().child("Product");
    ArrayList<product_modelclass> lst;

    Button New_Product;


    ImageView back;

//    @Override
//    public boolean onSupportNavigateUp() {
//        onBackPressed();
//        return true;
//    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_master);


        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        back = findViewById(R.id.back);
        New_Product = findViewById(R.id.product);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);
        lst = new ArrayList<>();
        adapter = new Product_adapter(this,lst);
        recyclerView.setAdapter(adapter);
        final ProgressDialog pd = ProgressDialog.show(Product_Master.this, "", "Please wait ..", true);

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                pd.show();
                for (DataSnapshot dataSnapshot : snapshot.getChildren()){
                    product_modelclass productModelclass = dataSnapshot.getValue(product_modelclass.class);
                    lst.add(productModelclass);

                }
                pd.dismiss();
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        New_Product = findViewById(R.id.product);
        New_Product.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Product_Master.this, New_ProductActivity.class);
                startActivity(i);
            }

        });
    }
}