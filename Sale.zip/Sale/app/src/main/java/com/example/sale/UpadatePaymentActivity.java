package com.example.sale;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class UpadatePaymentActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upadate_payment);
    }
}